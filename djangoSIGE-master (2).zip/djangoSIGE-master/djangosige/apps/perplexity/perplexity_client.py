import requests
from django.conf import settings

class PerplexityClient:
    BASE_URL = "https://api.perplexity.ai"

    def __init__(self):
        self.api_key = settings.PERPLEXITY_API_KEY

    def get_completion(self, messages, model="llama-3.1-sonar-large-128k-online"):
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        data = {
            "model": model,
            "messages": messages
        }
        response = requests.post(f"{self.BASE_URL}/chat/completions", headers=headers, json=data)
        return response.json()