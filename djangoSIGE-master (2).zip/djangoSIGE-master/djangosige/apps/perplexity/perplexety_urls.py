from django.urls import path
from .views import perplexity_assistente

urlpatterns = [
    path('assistant/', perplexity_assistant, name='perplexity_assistant'),
]
