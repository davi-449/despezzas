from django.http import JsonResponse
from .perplexity_client import PerplexityClient
from djangosige.apps.financeiro.models import MovimentoCaixa
from djangosige.apps.vendas.models import PedidoVenda
from djangosige.apps.cadastro.models import Cliente, Fornecedor, Produto, Empresa, Transportadora
from django.utils import timezone
from django.db.models import Sum


def perplexity_assistant(request):
    query = request.GET.get('query', '').lower()
    
    # Interprete a solicita o do usu rio e chame as fun es corretas
    if "agenda" in query or "hoje" in query:
        return get_agenda_hoje(request)
    elif "alerta" in query or "alertas" in query or "problemas" in query:
        return get_alertas(request)
    elif "cadastro" in query or "clientes" in query or "fornecedores" in query or "produtos" in query:
        return get_cadastros(request)
    elif "lucro" in query or "desempenho financeiro" in query or "financeiro" in query:
        return get_resumo_financeiro(request)
    elif "pedidos" in query or "vendas" in query or "compras" in query:
        return get_pedidos(request)
    elif "estoque" in query or "produtos em estoque" in query:
        return get_estoque(request)
    else:
        return JsonResponse({"resposta": "Desculpe, n o entendi sua solicita o."})


from django.http import JsonResponse
from djangosige.apps.financeiro.models import MovimentoCaixa
from djangosige.apps.vendas.models import PedidoVenda
from django.utils import timezone
from django.db.models import Sum

def get_agenda_hoje(request):
    hoje = timezone.now().date()

    # Pedidos de venda agendados para hoje
    pedidos_venda_hoje = PedidoVenda.objects.filter(data_entrega=hoje).count()

    # Contas a pagar hoje (ajustando para usar 'data_movimento' se for o campo correto)
    contas_pagar_hoje = MovimentoCaixa.objects.filter(data_movimento=hoje, saidas__gt=0).count()

    # Contas a receber hoje (ajustando para usar 'data_movimento' se for o campo correto)
    contas_receber_hoje = MovimentoCaixa.objects.filter(data_movimento=hoje, entradas__gt=0).count()

    # Contas a pagar amanhã
    amanha = hoje + timezone.timedelta(days=1)
    contas_pagar_amanha = MovimentoCaixa.objects.filter(data_movimento=amanha, saidas__gt=0).count()

    # Calcular saldo final (lucro) após pagar e receber as contas de hoje
    total_receber_hoje = MovimentoCaixa.objects.filter(data_movimento=hoje, entradas__gt=0).aggregate(total=Sum('entradas'))['total'] or 0
    total_pagar_hoje = MovimentoCaixa.objects.filter(data_movimento=hoje, saidas__gt=0).aggregate(total=Sum('saidas'))['total'] or 0

    lucro_final = total_receber_hoje - total_pagar_hoje

    resposta = f"""
        Hoje temos {pedidos_venda_hoje} pedidos de venda agendados, {contas_pagar_hoje} contas a pagar,
        com {contas_pagar_amanha} conta(s) vencendo amanhâ, e {contas_receber_hoje} conta(s) a receber hoje.
        Nosso lucro final após receber e pagar as contas ser  de R$ {lucro_final:.2f}.
    """
    
    return JsonResponse({"resposta": resposta})

from django.http import JsonResponse
from .perplexity_client import PerplexityClient  # Classe que faz chamadas à API da IA
from djangosige.apps.financeiro.models import MovimentoCaixa
from djangosige.apps.vendas.models import PedidoVenda
from djangosige.apps.cadastro.models import Produto
from django.utils import timezone

from djangosige.apps.vendas.models import OrcamentoVenda


def get_pedidos(request):
    # Coletar dados do sistema
    pedidos_venda = PedidoVenda.objects.all().count()
    pedidos_venda_faturados = PedidoVenda.objects.filter(status='FAT').count()
    pedidos_venda_cancelados = PedidoVenda.objects.filter(status='CAN').count()

    # Preparar os dados para enviar à IA
    resumo_dados = f"""
        Atualmente, temos {pedidos_venda} pedidos de venda, dos quais {pedidos_venda_faturados} foram faturados
        e {pedidos_venda_cancelados} foram cancelados.
    """
    
    # Enviar os dados para a IA (usando PerplexityClient ou outra API)
    client = PerplexityClient()  # Supondo que esta classe esteja configurada para fazer chamadas à API da IA
    
    messages = [
        {"role": "system", "content": "Você é um assistente de vendas."},
        {"role": "user", "content": f"Analise os seguintes dados e forneça dicas: {resumo_dados}"}
    ]
    
    # Fazer a chamada à API da IA e obter a resposta
    response = client.get_completion(messages)
    
    # Extrair a resposta da IA, garantindo que não haja erro na estrutura da resposta.
    analise_ia = response['choices'][0]['message']['content'] if 'choices' in response and response['choices'] else "Desculpe, não consegui gerar uma análise."

    # Retornar a resposta ao frontend
    return JsonResponse({
        "resumo": resumo_dados,
        "analise": analise_ia
    })



def get_cadastros(request):
    clientes = Cliente.objects.count()
    fornecedores = Fornecedor.objects.count()
    produtos = Produto.objects.count()
    empresas = Empresa.objects.count()
    transportadoras = Transportadora.objects.count()

    resposta = f"""
        Cadastros: Temos {clientes} clientes, {fornecedores} fornecedores,
        {produtos} produtos cadastrados, {empresas} empresas e {transportadoras} transportadoras.
    """
    
    return JsonResponse({"resposta": resposta})


def get_resumo_financeiro(request):
    hoje = timezone.now().date()

    # Lucro/prejuízo do dia
    lucro_prejuizo_dia = MovimentoCaixa.objects.filter(data_movimento=hoje).aggregate(total=Sum('saldo_final'))['total'] or 0

    resposta = f"""
        Resumo Financeiro: O Lucro de hoje é R$ {lucro_prejuizo_dia:.2f}.
        Verifique os detalhes no fluxo de caixa para mais informações.
    """
    
    return JsonResponse({"resposta": resposta})
