# -*- coding: utf-8 -*-

from .vendas import *
from .pagamento import *
