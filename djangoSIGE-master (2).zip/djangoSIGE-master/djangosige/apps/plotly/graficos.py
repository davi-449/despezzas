# graficos.py
import plotly.graph_objects as go

def criar_grafico_lucro():
    # Dados do gráfico
    dados = [
        ['Dia', 'Lucro'],
        [ MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[4].data, MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[4].valor ],
        [ MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[3].data, MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[3].valor ],
        [ MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[2].data, MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[2].valor ],
        [ MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[1].data, MovimentoCaixa.objects.filter(data__lt=datetime.date.today(), tipo_movimento='E').order_by('-data')[1].valor ],
        [ datetime.date.today(), MovimentoCaixa.objects.filter(data=datetime.date.today(), tipo_movimento='E').order_by('-data')[0].valor ]
    ]

    dias = [linha[0] for linha in dados[1:]]
    lucro = [linha[1] for linha in dados[1:]]

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dias, y=lucro, mode='lines+markers', name='Lucro'))

    fig.update_layout(
        title='Lucro Diário',
        xaxis_title='Dia',
        yaxis_title='Lucro',
        legend=dict(x=0, y=1, orientation='h'),
        hovermode='x'
    )

    return fig.to_html(full_html=False)