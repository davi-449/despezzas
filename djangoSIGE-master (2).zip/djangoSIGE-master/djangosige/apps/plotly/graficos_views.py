# views.py
from django.shortcuts import render
from .graficos import criar_grafico_lucro

def pagina_lucro(request):
    grafico_html = criar_grafico_lucro()
    return render(request, 'sua_template.html', {'grafico_html': grafico_html})